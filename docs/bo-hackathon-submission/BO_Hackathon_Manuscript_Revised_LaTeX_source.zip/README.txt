Bayesian Optimization Hackathon for Chemistry and Materials
Digital Discovery manuscript DD-ART-06-2026-000353, revised version: LaTeX source

Compile (no shell-escape needed):
    pdflatex main
    bibtex main
    pdflatex main
    pdflatex main

main.bbl is included, so the bibtex step is optional.
Class: revtex4-2 (standard TeX Live). Figures 1-5 are in latex/figures/.
